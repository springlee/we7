<?php
if (!(defined("IN_IA"))) 
{
	exit("Access Denied");
}
require EWEI_SHOPV2_PLUGIN . "pc/core/common.php";
class PcMobilePage extends PluginMobilePage 
{
}
?>